import { Link, useLocation } from "wouter";
import { Home, Gamepad2, Trophy } from "lucide-react";
import { AdBanner } from "./ad-banner";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="mx-auto w-full max-w-[430px] min-h-[100dvh] bg-white relative pb-32 shadow-2xl flex flex-col">
      <main className="flex-1 flex flex-col relative w-full h-full overflow-x-hidden">
        {children}
      </main>
      
      <div className="fixed bottom-0 w-full max-w-[430px] z-50 bg-white border-t border-gray-100 pb-safe">
        <AdBanner />
        <nav className="flex justify-around items-center h-16 px-4">
          <Link href="/" className={`flex flex-col items-center justify-center w-full h-full ${location === "/" ? "text-primary" : "text-gray-400"}`}>
            <Home className="w-6 h-6 mb-1" />
            <span className="text-[10px] font-medium">Home</span>
          </Link>
          <div className="flex flex-col items-center justify-center w-full h-full text-gray-400">
            <Gamepad2 className="w-6 h-6 mb-1" />
            <span className="text-[10px] font-medium">Games</span>
          </div>
          <Link href="/leaderboard" className={`flex flex-col items-center justify-center w-full h-full ${location === "/leaderboard" ? "text-primary" : "text-gray-400"}`}>
            <Trophy className="w-6 h-6 mb-1" />
            <span className="text-[10px] font-medium">Rank</span>
          </Link>
        </nav>
      </div>
    </div>
  );
}
